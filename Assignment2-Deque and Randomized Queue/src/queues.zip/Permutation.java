import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdIn;

public class Permutation {
	public static void main(String[] args) {

		int numToPrint;
		RandomizedQueue<String> RQ = new RandomizedQueue<> ();
		
		while (!StdIn.isEmpty()) {
//			StdOut.println(StdIn.readString());
			RQ.enqueue(StdIn.readString());
		}
		
		numToPrint = Integer.parseInt(args[0]); 
//		StdOut.println(numToPrint);
		
		while (numToPrint > 0) {
			StdOut.println(RQ.dequeue());
			numToPrint--;
		}
		
		
	}
}


//public class Permutation {
//    public static void main(String[] args)
//    {
//        RandomizedQueue<String> strs = new RandomizedQueue<String>();
//        while (!StdIn.isEmpty()) {
//            strs.enqueue(StdIn.readString());
//        }
//        
//        int k = Integer.parseInt(args[0]);
//        for (int i = 0; i < k; i++) {
//            StdOut.println(strs.dequeue());
//        }
//    }
//}