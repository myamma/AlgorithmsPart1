import edu.princeton.cs.algs4.StdOut;
import java.util.Arrays;
import java.util.ArrayList;

public class FastCollinearPoints {

	private ArrayList<LineSegment> lineSeg = new ArrayList<LineSegment>();
	private Point origin;
	private double[] slopes;
	private Point[] other;
	
	// finds all line segments containing 4 or more points
	public FastCollinearPoints(Point[] points) {
		
		checkValidity(points);
		
		//sort array in natural order as specified with comparable
		//interface
		Arrays.sort(points);
		
		for (int i = 0; i < points.length - 1; i++) 
			if (points[i].compareTo(points[i+1]) == 0)
				throw new java.lang.IllegalArgumentException();
		
		for (int i = 0; i < points.length; i++) {
//			StdOut.println(points[i]);
			origin = points[i];
			slopes = new double[points.length - 1 - i];
			other = new Point[points.length - 1 - i];
			
			for (int j =0; j < points.length - 1 - i; j++) {
				other[j] = points[i + 1 +j];
			}
			
			for (int j =0; j < points.length - 1 - i; j++) {
				slopes[j] = origin.slopeTo(other[j]);
			}
			
			//sort points in others by slope they formed with origin
			Arrays.sort(other, origin.slopeOrder());
			
			//sort slope by natural order
			Arrays.sort(slopes);
			
			for (int sameCount = 1, j = 0; j < slopes.length - 1; 
					j++) {
				if (slopes[j] == slopes[j+1]) {
					sameCount++;
				}
				if (sameCount >= 2) {
					lineSeg.add(new LineSegment(origin, other[j + 1]));
					break;
				}
			}
			
			
		}
		

	}
	
	private void checkValidity(Point[] points) {
		if (points == null) {throw new IllegalArgumentException("points array can't be null");}
		for (Point i: points) {
			if(i == null) {throw new IllegalArgumentException("can't have null points in array");}
		}
	}

	// the number of line segments
	public int numberOfSegments() {return lineSeg.size();}
	
	// the line segments
	public LineSegment[] segments() {
		LineSegment[] result = new LineSegment[lineSeg.size()];
		for(int i = 0; i<lineSeg.size(); i++) {
			result[i] = lineSeg.get(i);
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		
		Point[] points = new Point[8];
		points[0] = new Point(10000, 0);
		points[1] = new Point(0, 10000);
		points[2] = new Point(3000, 7000);
		points[3] = new Point(7000, 3000);
		points[4] = new Point(20000, 21000);
		points[5] = new Point(3000, 4000);
		points[6] = new Point(14000, 15000);
		points[7] = new Point(6000, 7000);
		
		FastCollinearPoints collinear = new FastCollinearPoints(points);
		
		
	}
	
}
